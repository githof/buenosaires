<?php

    $page_title = "Déconnexion";

?>

<div>
    Déconnecté avec succès
</div>
