	<form action="viewGroupe.php" method="post">
		<label for="groupe" >Dans quelle categorie souhaitez-vous les enegistrer ? ?</label><br />
			<select id="groupe" class="liste">
			   <option value=" "> EN ATTENTE</option>     
			</select><br /><br />
		   
		   <p><input type="text" name="texte" /></p>
		   
		  <select id="option" class="liste">
			   <option value=" "> Creer</option>
			   <option value=" "> Afficher</option>
			   <option value=" "> Supprimer</option>
			   <option value=" "> Exporter</option>     
			</select><br /><br />
		  <input type="submit" class="bouton" value="ajouter au groupe sélectionné" />
		  
  </form>

