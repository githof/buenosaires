<?php include("../includes/header.php"); ?>

<h1>ZONE RESTREINTE</h1>

<p class="p_accueil">Vous n'avez pas les droits suffisants pour acc&eacute;der &agrave; cette page.</p>

<?php include("../includes/footer.php"); ?>