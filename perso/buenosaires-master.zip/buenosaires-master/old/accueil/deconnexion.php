<?php 
include_once("../includes/account_log.php");
supprimer_cookie(); 
?>
<?php
include("../includes/header.php");
?>

<h1>DECONNEXION</h1>


<p class="p_accueil">Vous avez bien &eacute;t&eacute; d&eacute;connect&eacute;-e.</p>

<?php include("../includes/footer.php"); ?>