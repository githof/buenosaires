<?php include("../includes/header.php"); ?>

<h1>BIENVENUE</h1>

<p class="p_accueil">Projet de recherche sur les actes de mariages de Buenos Aires au XVIIe et XVIIIe si&eacute;cle</p>

<?php include("../includes/footer.php"); ?>
