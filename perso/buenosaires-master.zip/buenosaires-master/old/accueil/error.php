<?php include("../includes/header.php"); ?>

<h1>PAGE ERREUR</h1>

<p class="p_accueil">Une erreur est survenue lors de votre op&eacute;ration. Si elle persiste, merci de pr&eacute;venir la webmaster.</p>

<?php include("../includes/footer.php"); ?>