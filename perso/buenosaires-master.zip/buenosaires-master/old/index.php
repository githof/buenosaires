<?php
  header('Location: accueil/');
  exit;
?>
