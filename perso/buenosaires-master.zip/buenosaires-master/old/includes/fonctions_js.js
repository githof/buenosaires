// JavaScript Document

function allerVers(url){
	 document.location.href=""+url;
}
