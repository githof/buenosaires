<?php
include("includes/fonctions_compilation.php");
?>
<p>bob</p>
