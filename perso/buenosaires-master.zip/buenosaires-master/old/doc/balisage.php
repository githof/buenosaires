
Le mieux est de suivre la procédure suivante :

- repérer dans matrimonios.shuffle.xml la liste des actes qui nous intéressent et qui n'ont pas encore été balisés
- ouvrir le fichier matrimonios.ajout.xml et étiqueter dedans les actes repérés
- charger les actes dans la base : 
http://www.liafa.univ-paris-diderot.fr/~buenosaires/importexport/ajouter_acte.php

La dernière étape, on pourra la faire ensemble au moins une fois.  Elle nécessite que tu sois connecté sur la base, et donc que tu te souviennes de ton mot de passe et ton nom d'utilisateur !! (qu'on pourra réinitialiser si nécessaire).

NB : le fichier ajout est issu de l'étiquetage automatique exclusivement, à l'exception de l'acte 1, que j'ai mis pour permettre au logiciel de savoir quelles étiquettes on utilise.  Donc à part cet acte, aucun des étiquetages manuels n'y figurent, mais l'étiquetage automatique préliminaire permet de faciliter grandement l'étiquetage manuel.

Attention : si tu constates des erreurs dans l'étiquetage automatique, corrige-les, et consigne-les (au moins le numéro de l'acte et éventuellement un bref commentaire sur l'erreur) dans un fichier texte ou doc.

