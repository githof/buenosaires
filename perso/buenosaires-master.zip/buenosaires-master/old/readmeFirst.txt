
------------------------------------------------------------------------------
                              Si on travaille local :
------------------------------------------------------------------------------

Pour utiliser les pages de parsing, il faut cr�er une base de donn�e mysql :

buenosaires

------------------------------------------------------------------------------
                        Si on ne travaille pas en local :
------------------------------------------------------------------------------

Pour utiliser les pages de parsing, il faut cr�er une base de donn�e mysql :

buenosaires

Et ensuite entrer les informations de connexion de mysql dans le fichier :

./info/parametre.php

------------------------------------------------------------------------------
                                     Ensuite :
------------------------------------------------------------------------------

Ouvrir dans un navigateur web :

./index.php

Voir le r�sultat dans la base de donn�e

------------------------------------------------------------------------------
                                     NOTA BENE :
------------------------------------------------------------------------------

Il faut PHP 5.1 au minimum
